import { useState } from "react";
import {
  ChevronDown,
  ChevronLeft,
  Menu,
  MapPin,
  Share2,
  BarChart3,
  Users,
  Facebook,
  Instagram,
  Link as LinkIcon
} from "lucide-react";
import { PinIcon } from "./PinIcon";
import { PinPalsLogo } from "./PinPalsLogo";

interface ProfileData {
  name: string;
  avatar: string;
  email: string;
}

interface ConnectionData {
  id: number;
  name: string;
  avatar: string;
  status: string;
}

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const profile: ProfileData = {
    name: "Alex Johnson",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    email: "alex@example.com"
  };

  const analytics = {
    lostPins: 12,
    foundPins: 8,
    helpPins: 5
  };

  const connections: ConnectionData[] = [
    { id: 1, name: "Sarah Miller", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=50&h=50&fit=crop", status: "Active" },
    { id: 2, name: "Mike Chen", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop", status: "Active" },
    { id: 3, name: "Emma Davis", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop", status: "Away" },
    { id: 4, name: "James Wilson", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=50&h=50&fit=crop", status: "Active" }
  ];

  const socialMedias = [
    { name: "Facebook", icon: Facebook, color: "#1877F2" },
    { name: "X", icon: null, color: "#000000", customIcon: true },
    { name: "Instagram", icon: Instagram, color: "#E4405F" },
    { name: "Copy Link", icon: LinkIcon, color: "#6B7280" }
  ];

  const toggleDropdown = (name: string) => {
    setOpenDropdown(openDropdown === name ? null : name);
  };

  return (
    <div
      className={`${
        isCollapsed ? "w-20" : "w-80"
      } h-screen bg-gradient-to-b from-slate-900 to-slate-800 text-white transition-all duration-300 ease-in-out flex flex-col shadow-2xl`}
    >
      {/* Header with toggle */}
      <div className="p-4 flex items-center justify-between border-b border-slate-700">
        {!isCollapsed && <PinPalsLogo className="h-8" />}
        <button
          onClick={() => {
            setIsCollapsed(!isCollapsed);
            setOpenDropdown(null);
          }}
          className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
          aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {isCollapsed ? <Menu size={24} /> : <ChevronLeft size={24} />}
        </button>
      </div>

      {/* Profile Badge */}
      <div className="p-4 border-b border-slate-700">
        <button
          onClick={() => toggleDropdown("profile")}
          className={`w-full ${
            isCollapsed ? "justify-center" : "justify-between"
          } flex items-center gap-3 p-3 bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={profile.avatar}
              alt={profile.name}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500"
            />
            {!isCollapsed && (
              <div className="text-left min-w-0">
                <p className="font-semibold truncate">{profile.name}</p>
                <p className="text-xs text-slate-400 truncate">{profile.email}</p>
              </div>
            )}
          </div>
          {!isCollapsed && (
            <ChevronDown
              size={20}
              className={`transition-transform flex-shrink-0 ${
                openDropdown === "profile" ? "rotate-180" : ""
              }`}
            />
          )}
        </button>
      </div>

      {/* Menu Items */}
      <div className="flex-1 overflow-y-auto py-4">
        {/* Create Pin */}
        <div className="px-4 mb-2">
          <button
            onClick={() => toggleDropdown("createPin")}
            className={`w-full flex items-center ${
              isCollapsed ? "justify-center" : "justify-between"
            } p-3 hover:bg-slate-700 rounded-lg transition-colors`}
          >
            <div className="flex items-center gap-3">
              <MapPin size={20} className="flex-shrink-0" />
              {!isCollapsed && <span className="font-medium">Create Pin</span>}
            </div>
            {!isCollapsed && (
              <ChevronDown
                size={16}
                className={`transition-transform ${
                  openDropdown === "createPin" ? "rotate-180" : ""
                }`}
              />
            )}
          </button>

          {openDropdown === "createPin" && !isCollapsed && (
            <div className="mt-2 ml-4 space-y-1 border-l-2 border-slate-700 pl-4">
              <button className="w-full flex items-center gap-3 p-2 hover:bg-slate-700 rounded-lg transition-colors text-left">
                <PinIcon className="w-5 h-5 flex-shrink-0" type="lost" />
                <span className="text-sm">Lost Pin</span>
              </button>
              <button className="w-full flex items-center gap-3 p-2 hover:bg-slate-700 rounded-lg transition-colors text-left">
                <PinIcon className="w-5 h-5 flex-shrink-0" type="found" />
                <span className="text-sm">Found Pin</span>
              </button>
              <button className="w-full flex items-center gap-3 p-2 hover:bg-slate-700 rounded-lg transition-colors text-left">
                <PinIcon className="w-5 h-5 flex-shrink-0" type="help" />
                <span className="text-sm">Help Pin</span>
              </button>
            </div>
          )}
        </div>

        {/* Share Pin */}
        <div className="px-4 mb-2">
          <button
            onClick={() => toggleDropdown("share")}
            className={`w-full flex items-center ${
              isCollapsed ? "justify-center" : "justify-between"
            } p-3 hover:bg-slate-700 rounded-lg transition-colors`}
          >
            <div className="flex items-center gap-3">
              <Share2 size={20} className="flex-shrink-0" />
              {!isCollapsed && <span className="font-medium">Share Your Pin</span>}
            </div>
            {!isCollapsed && (
              <ChevronDown
                size={16}
                className={`transition-transform ${
                  openDropdown === "share" ? "rotate-180" : ""
                }`}
              />
            )}
          </button>

          {openDropdown === "share" && !isCollapsed && (
            <div className="mt-2 ml-4 border-l-2 border-slate-700 pl-4">
              <div className="grid grid-cols-2 gap-2">
                {socialMedias.map((social) => {
                  const Icon = social.icon;
                  return (
                    <button
                      key={social.name}
                      className="flex flex-col items-center gap-1 p-2 hover:bg-slate-700 rounded-lg transition-colors"
                      title={social.name}
                    >
                      {social.customIcon ? (
                        <svg
                          viewBox="0 0 24 24"
                          fill="currentColor"
                          className="w-5 h-5"
                          style={{ color: social.color }}
                        >
                          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                        </svg>
                      ) : (
                        Icon && <Icon size={20} style={{ color: social.color }} />
                      )}
                      <span className="text-xs text-slate-400">{social.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Analytics */}
        <div className="px-4 mb-2">
          <button
            onClick={() => toggleDropdown("analytics")}
            className={`w-full flex items-center ${
              isCollapsed ? "justify-center" : "justify-between"
            } p-3 hover:bg-slate-700 rounded-lg transition-colors`}
          >
            <div className="flex items-center gap-3">
              <BarChart3 size={20} className="flex-shrink-0" />
              {!isCollapsed && <span className="font-medium">Analytics</span>}
            </div>
            {!isCollapsed && (
              <ChevronDown
                size={16}
                className={`transition-transform ${
                  openDropdown === "analytics" ? "rotate-180" : ""
                }`}
              />
            )}
          </button>

          {openDropdown === "analytics" && !isCollapsed && (
            <div className="mt-2 ml-4 space-y-2 border-l-2 border-slate-700 pl-4">
              <div className="flex items-center justify-between p-2 bg-slate-800/50 rounded-lg">
                <div className="flex items-center gap-2">
                  <PinIcon className="w-4 h-4" type="lost" />
                  <span className="text-sm">Lost Pins</span>
                </div>
                <span className="font-bold text-red-400">{analytics.lostPins}</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-800/50 rounded-lg">
                <div className="flex items-center gap-2">
                  <PinIcon className="w-4 h-4" type="found" />
                  <span className="text-sm">Found Pins</span>
                </div>
                <span className="font-bold text-green-400">{analytics.foundPins}</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-800/50 rounded-lg">
                <div className="flex items-center gap-2">
                  <PinIcon className="w-4 h-4" type="help" />
                  <span className="text-sm">Help Pins</span>
                </div>
                <span className="font-bold text-yellow-400">{analytics.helpPins}</span>
              </div>
            </div>
          )}
        </div>

        {/* Connections */}
        <div className="px-4 mb-2">
          <button
            onClick={() => toggleDropdown("connections")}
            className={`w-full flex items-center ${
              isCollapsed ? "justify-center" : "justify-between"
            } p-3 hover:bg-slate-700 rounded-lg transition-colors`}
          >
            <div className="flex items-center gap-3">
              <Users size={20} className="flex-shrink-0" />
              {!isCollapsed && <span className="font-medium">Connections</span>}
              {!isCollapsed && (
                <span className="text-xs bg-blue-500 text-white px-2 py-0.5 rounded-full">
                  {connections.length}
                </span>
              )}
            </div>
            {!isCollapsed && (
              <ChevronDown
                size={16}
                className={`transition-transform ${
                  openDropdown === "connections" ? "rotate-180" : ""
                }`}
              />
            )}
          </button>

          {openDropdown === "connections" && !isCollapsed && (
            <div className="mt-2 ml-4 space-y-2 border-l-2 border-slate-700 pl-4">
              {connections.map((connection) => (
                <button
                  key={connection.id}
                  className="w-full flex items-center gap-3 p-2 hover:bg-slate-700 rounded-lg transition-colors text-left"
                >
                  <img
                    src={connection.avatar}
                    alt={connection.name}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{connection.name}</p>
                    <p className="text-xs text-slate-400">{connection.status}</p>
                  </div>
                  <div
                    className={`w-2 h-2 rounded-full flex-shrink-0 ${
                      connection.status === "Active" ? "bg-green-400" : "bg-slate-500"
                    }`}
                  />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
