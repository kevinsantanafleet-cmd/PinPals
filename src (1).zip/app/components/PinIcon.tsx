export function PinIcon({ className = "", type = "lost" }: { className?: string; type?: "lost" | "found" | "help" }) {
  const colors = {
    lost: "#EF4444",
    found: "#10B981",
    help: "#EAB308"
  };

  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Pin shadow */}
      <ellipse
        cx="12"
        cy="22"
        rx="3"
        ry="0.5"
        fill="black"
        opacity="0.2"
      />

      {/* Pin body */}
      <path
        d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"
        fill={colors[type]}
        stroke="#000"
        strokeWidth="0.5"
        opacity="0.9"
      />

      {/* Pin highlight */}
      <path
        d="M12 2C8.13 2 5 5.13 5 9c0 1.5 0.5 3 1.5 4.5"
        fill="none"
        stroke="white"
        strokeWidth="0.8"
        opacity="0.3"
        strokeLinecap="round"
      />

      {/* Inner circle */}
      <circle
        cx="12"
        cy="9"
        r="3"
        fill="white"
        opacity="0.9"
      />

      {/* Center dot */}
      <circle
        cx="12"
        cy="9"
        r="1.5"
        fill={colors[type]}
      />
    </svg>
  );
}
