export function PinPalsLogo({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 60"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* First P with pin design */}
      <g>
        {/* P stem */}
        <path
          d="M10 15 L10 45 L15 45 L15 15 Z"
          fill="#0070BA"
        />
        {/* P bowl with pin top */}
        <path
          d="M15 15 L30 15 Q40 15 40 25 Q40 32 32 34 L28 45 L25 45 L29 33 Q35 31 35 25 Q35 20 30 20 L20 20 L20 15 Z"
          fill="#0070BA"
        />
        {/* Pin circle */}
        <circle cx="28" cy="25" r="3" fill="white" opacity="0.8" />
      </g>

      {/* Second overlapping P with pin design */}
      <g transform="translate(18, 0)">
        {/* P stem */}
        <path
          d="M10 15 L10 45 L15 45 L15 15 Z"
          fill="#00457C"
        />
        {/* P bowl with pin top */}
        <path
          d="M15 15 L30 15 Q40 15 40 25 Q40 32 32 34 L28 45 L25 45 L29 33 Q35 31 35 25 Q35 20 30 20 L20 20 L20 15 Z"
          fill="#00457C"
        />
        {/* Pin circle */}
        <circle cx="28" cy="25" r="3" fill="white" opacity="0.8" />
      </g>

      {/* Text "als" */}
      <text
        x="65"
        y="38"
        fontFamily="Arial, sans-serif"
        fontSize="28"
        fontWeight="600"
        fill="#0070BA"
      >
        als
      </text>
    </svg>
  );
}
