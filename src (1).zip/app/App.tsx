import { Sidebar } from "./components/Sidebar";

export default function App() {
  return (
    <div className="size-full flex bg-slate-100">
      <Sidebar />
      <div className="flex-1 p-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="mb-4">Main Content Area</h1>
          <p className="text-slate-600">
            Click the profile badge or menu items in the sidebar to see the dropdowns in action.
            Use the toggle button to collapse/expand the sidebar.
          </p>
        </div>
      </div>
    </div>
  );
}